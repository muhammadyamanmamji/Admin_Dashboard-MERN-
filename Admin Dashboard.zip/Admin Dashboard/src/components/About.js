const About = () => {
    return (
      <div>
      <h1>Welcome to our Admin Dashboard!</h1>
      <p>Our Admin Dashboard is a secure platform designed to empower individuals to create their personal dashboards, where they can manage their private notes with confidence and privacy.</p>
      <p>Unlike traditional note-taking applications, our dashboard ensures that each user has exclusive access to their own notes, providing a safe and personalized environment for organizing and storing important information.</p>
      
      <hr />
      
      <h2>Key Features:</h2>
      <ul>
          <li>
              <strong>Personalized Dashboards:</strong> Every user can create their own personalized dashboard tailored to their preferences and needs. They can customize their dashboard layout, organize notes into categories, and personalize the interface according to their liking.
          </li>
          <li>
              <strong>Private Notes:</strong> Our platform prioritizes user privacy and security. Each user's notes are completely private and inaccessible to other users. This ensures that sensitive information remains confidential and protected from unauthorized access.
          </li>
          <li>
              <strong>Secure Authentication:</strong> We employ robust authentication mechanisms to ensure that only authorized users can access their dashboard. Users can securely log in using their credentials, and all interactions within the dashboard are encrypted to safeguard data integrity.
          </li>
          <li>
              <strong>User-Friendly Interface:</strong> Our dashboard features an intuitive and user-friendly interface that makes it easy for users to navigate, create, edit, and delete notes effortlessly. With simple yet powerful tools, users can efficiently manage their notes and stay organized.
          </li>
          <li>
              <strong>Continuous Improvement:</strong> We are committed to continuously enhancing our platform to provide the best user experience possible. We regularly update and improve features based on user feedback and evolving security standards, ensuring that our dashboard remains a reliable and indispensable tool for personal productivity.
          </li>
      </ul>
      
      <hr />
      
      <p>Whether you're a student, professional, or simply someone who values privacy and organization, our Admin Dashboard is your trusted companion for managing your personal notes securely and efficiently.</p>
  </div>
    )
  }
  
  export default About;
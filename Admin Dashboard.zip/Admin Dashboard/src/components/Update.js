import React from 'react';
import Home from './Home';

const ParentComponent = () => {
    const updateNote = (currentNote) => {
        ref.current.click();
        setNote({ id: currentNote._id, etitle: currentNote.title, edescription: currentNote.description, etag: currentNote.tag });
    }

  return <Home updateNote={updateNote} />;
};

export default ParentComponent;

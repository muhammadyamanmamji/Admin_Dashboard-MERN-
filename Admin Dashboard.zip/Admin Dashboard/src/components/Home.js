
  import React, { useState, useEffect, useContext, useRef } from 'react';
import AddNote from './AddNote';
import { Empty, Skeleton, Tag } from 'antd';
import noteContext from '../context/notes/noteContext';
import './Home.css';

const Home = () => {
  const host = "http://localhost:5000";
  const [allList, setAllList] = useState([]);
  const [loader, setLoader] = useState(false);
  const [note, setNote] = useState({ id: "", etitle: "", edescription: "", etag: "" });
  const ref = useRef(null);

  const context = useContext(noteContext);
  const { notes, getNotes, editNote, deleteNote } = context;

  useEffect(() => {
    try {
      setLoader(true);
      fetch(`${host}/api/notes/fetchallnotes`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "auth-token": localStorage.getItem('token')
        }
      })
        .then(res => res.json())
        .then((response) => {
          setLoader(false);
          setAllList(response);
        });
    } catch (err) {
      console.error(err);
      setLoader(false);
    }
  }, []);

  const updateNote = (currentNote) => {
    ref.current.click();
    setNote({
      id: currentNote._id,
      etitle: currentNote.title,
      edescription: currentNote.description,
      etag: currentNote.tag
    });
  };

  const handleClick = () => {
    console.log("Updating the Note", note);
    editNote(note.id, note.etitle, note.edescription, note.etag);
  };

  const onChange = (e) => {
    setNote({ ...note, [e.target.name]: e.target.value });
  };

  return (
    <div>
      <AddNote />
      <button ref={ref} type="button" className="btn btn-primary d-none" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Launch demo modal
      </button>
      <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">Edit Note</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <form className='my-3'>
                <div className="mb-3">
                  <label htmlFor="title" className="form-label">Title</label>
                  <input type="text" className="form-control" id="etitle" name='etitle' value={note.etitle} aria-describedby="emailHelp" onChange={onChange} />
                </div>
                <div className="mb-3">
                  <label htmlFor="description" className="form-label">Description</label>
                  <input type="text" className="form-control" id="edescription" name='edescription' value={note.edescription} onChange={onChange} />
                </div>
                <div className="mb-3">
                  <label htmlFor="tag" className="form-label">Tag</label>
                  <input type="text" className="form-control" id="etag" name='etag' value={note.etag} onChange={onChange} />
                </div>
              </form>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button disabled={note.etitle.length < 5 || note.edescription.length < 5} onClick={handleClick} type="button" className="btn btn-primary" data-bs-dismiss="modal" >Update Dashboard</button>
            </div>
          </div>
        </div>
      </div>
      <div className='row my-3'>
        <h2>Your Dashboard </h2>
        <div className='container mx-2'>
          {loader ? (
            <>
              <Skeleton active={true} />
              <Skeleton active={true} />
            </>
          ) : allList !== undefined && allList !== null && allList.length > 0 ? (
            allList.map(data => (
              <div className='listItemRender' key={data._id}>
                {data?.tag ? <Tag color="Blue">{data?.tag}</Tag> : ""}
                <h3 style={{ paddingTop: 10 }}>{data?.title}</h3>
                <p>{data?.description}</p>
                <div>
                  <i className="fa-solid fa-trash mx-2" onClick={() => deleteNote(data._id)}></i>
                  <i className="fa-solid fa-pen-to-square mx-2" onClick={() => updateNote(data)}></i>
                </div>
              </div>
            ))
          ) : (
            <Empty />
          )}
        </div>
      </div>
    </div >
  );
};

export default Home;

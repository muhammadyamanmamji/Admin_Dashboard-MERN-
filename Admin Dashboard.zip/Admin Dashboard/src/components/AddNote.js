import React, { useContext, useState } from 'react'
import { message } from 'antd'

const AddNote = () => {
    const host = "http://localhost:5000"

    const [formData, setFormData] = useState({ title: "", description: "", tag: "" })
    const [loader, setLoader] = useState(false)

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevFormData) => ({ ...prevFormData, [name]: value }));
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        try {
            setLoader(true)
            fetch(`${host}/api/notes/addnote`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "auth-token": localStorage.getItem('token')
                },
                body: JSON.stringify({ title: formData.title, description: formData.description, tag: formData.tag }),
            })
                .then(res => res.json())
                .then(responce => {
                    if (responce.user) {
                        message.success('Note Created')
                        setLoader(false)
                        setFormData({ title: "", description: "", tag: "" })
                    }
                    else {
                        message.error('Something went wrong')
                        setLoader(false)
                        setFormData({ title: "", description: "", tag: "" })
                    }
                })
        }
        catch (err) {
            console.error(err);
            setLoader(false)
            setFormData({ title: "", description: "", tag: "" })
        }
    };

    return (
        <>
            <div className='container my-3 main-note-add'>
                <h2>Create your Dashboard</h2>
                <form onSubmit={handleSubmit} className='my-3'>
                    <div className="mb-3">
                        <label htmlFor="title" className="form-label">Title</label>
                        <input required={true} placeholder='Title' type="text" className="form-control" onChange={handleChange} value={formData.title} id="title" name='title' aria-describedby="emailHelp" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="description" className="form-label">Description</label>
                        <input required={true} placeholder="description" type="text" className="form-control" onChange={handleChange} value={formData.description} id="description" name='description' />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="tag" className="form-label">Tag</label>
                        <input required={true} placeholder="tag" type="text" className="form-control" onChange={handleChange} value={formData.tag} id="tag" name='tag' />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        {loader ?
                            <div class="spinner-border text-light " role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                            : "Create"}
                    </button>
                </form>
            </div>

        
        </>
    )
}

export default AddNote

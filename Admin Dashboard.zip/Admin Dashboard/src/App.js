import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import About from "./components/About";
import NoteState from "./context/notes/NoteState";
import Login from "./components/Login";
import Signup from "./components/Signup";

function App() {
  const tokenCon = localStorage.getItem('token')
  return (
    <NoteState>
      <Router>
        <Navbar />
        <div className="container">
          <Routes>
          <Route path="/" element={tokenCon?<Home/>:<Login />} />
            <Route path="/about" element={<About />} />
            <Route path="/signup" element={<Signup />} />
          </Routes>
        </div>
      </Router>
    </NoteState>
  );
}

export default App;
